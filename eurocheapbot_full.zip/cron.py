import sqlite3
from telegram import Bot
from parser import get_price_from_url

BOT_TOKEN = "7595128508:AAFsDGjxQtnHFTT7dBcN9yfmSV-359GhqbY"

conn = sqlite3.connect("eurocheap.db", check_same_thread=False)
c = conn.cursor()

bot = Bot(token=BOT_TOKEN)

rows = c.execute("SELECT rowid, user_id, url, initial_price, last_price FROM items").fetchall()

for row in rows:
    rowid, user_id, url, initial, last = row
    current = get_price_from_url(url)
    if current:
        drop = 100 - current * 100 // initial
        if drop >= 30:
            bot.send_message(chat_id=user_id,
                             text=f"🔔 Цена упала на {drop}%!\n{url}\n💸 Было: {initial} ₽ → Сейчас: {current} ₽")
            c.execute("DELETE FROM items WHERE rowid = ?", (rowid,))
            conn.commit()
        else:
            c.execute("UPDATE items SET last_price = ? WHERE rowid = ?", (current, rowid))
            conn.commit()