import requests
from bs4 import BeautifulSoup

def get_price_from_url(url):
    headers = {"User-Agent": "Mozilla/5.0"}
    try:
        r = requests.get(url, headers=headers)
        soup = BeautifulSoup(r.text, "html.parser")

        if "ozon" in url:
            m = soup.find("meta", itemprop="price")
            return int(float(m["content"])) if m else None

        if "wildberries" in url:
            p = soup.find("span", class_="price-block__final-price")
            if p:
                return int(p.text.replace("₽", "").replace(" ", "").strip())

        if "market.yandex" in url:
            p = soup.find("span", {"data-auto": "mainPrice"})
            if p:
                return int(p.text.replace("₽", "").replace(" ", "").strip())

    except Exception as e:
        print("Ошибка при парсинге:", e)

    return None