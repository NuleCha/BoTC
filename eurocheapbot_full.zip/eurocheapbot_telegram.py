import logging
import sqlite3
from telegram import Update
from telegram.ext import Application, CommandHandler, ContextTypes
from parser import get_price_from_url

BOT_TOKEN = "7595128508:AAFsDGjxQtnHFTT7dBcN9yfmSV-359GhqbY"

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

conn = sqlite3.connect("eurocheap.db", check_same_thread=False)
c = conn.cursor()
c.execute("""
CREATE TABLE IF NOT EXISTS items (
    user_id INTEGER,
    url TEXT,
    initial_price INTEGER,
    last_price INTEGER
)
""")
conn.commit()

async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.message.reply_text("Привет! Я EuroCheapBot. Кидай ссылку на товар через /add <ссылка>")

async def add(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user_id = update.message.from_user.id
    if not context.args:
        return await update.message.reply_text("Формат: /add https://...")

    url = context.args[0]
    price = get_price_from_url(url)
    if price:
        c.execute("INSERT INTO items (user_id, url, initial_price, last_price) VALUES (?, ?, ?, ?)",
                  (user_id, url, price, price))
        conn.commit()
        await update.message.reply_text(f"✅ Добавлено: {url}\nНачальная цена: {price} ₽")
    else:
        await update.message.reply_text("❌ Не удалось получить цену. Проверь ссылку.")

async def list_items(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user_id = update.message.from_user.id
    rows = c.execute("SELECT url, initial_price, last_price FROM items WHERE user_id = ?", (user_id,)).fetchall()
    if not rows:
        return await update.message.reply_text("У тебя пока нет отслеживаемых товаров.")

    message = "📦 Отслеживаемые товары:\n"
    for url, initial, last in rows:
        drop = 100 - int(last) * 100 // int(initial)
        message += f"\n{url}\n🔒 Было: {initial} ₽ → Сейчас: {last} ₽ (−{drop}%)\n"
    await update.message.reply_text(message)

async def main():
    app = Application.builder().token(BOT_TOKEN).build()
    app.add_handler(CommandHandler("start", start))
    app.add_handler(CommandHandler("add", add))
    app.add_handler(CommandHandler("list", list_items))
    await app.run_polling()

if __name__ == "__main__":
    import asyncio
    asyncio.run(main())